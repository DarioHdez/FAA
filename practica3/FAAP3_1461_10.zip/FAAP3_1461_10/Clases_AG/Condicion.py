

class Condicion(object):

    def __init__(self,valor,Tabla):
        pass
        # (self.minimo,self.maximo),self.intervalo = Tabla. (valor)

