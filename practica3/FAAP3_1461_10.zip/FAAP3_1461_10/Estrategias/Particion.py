# -*- coding: utf-8 -*-

class Particion():

    # Esta clase mantiene la lista de indices de Train y Test para cada partición del conjunto de particiones
    def __init__(self):
        self.indicesTrain = []
        self.indicesTest = []
